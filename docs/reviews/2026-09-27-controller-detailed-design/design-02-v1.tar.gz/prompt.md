使用者指定這個名為 opus 的 session，接手 orca-delivery controller 的 Implementer 設計工作。這不是 gigaxfer 任務。請先讀 /private/tmp/orca-controller-bootstrap-20260927/opus-session-design-02/assignment.json 與 input-manifest.json，再讀 inputs/docs/handoffs/2026-09-27-controller-design.md 與它在快照內的依賴文件。輸入以 inputs 下固定快照為準；live repo 僅作必要唯讀查核，若版本矛盾回報。

本輪只做詳細設計與 implementation plan 草稿。D36/D39 指定 Opus 5.5；請核對可取得的 model 身份證據，若非指定模型則停止並回報。畫面型號不是 actual inference 證據，不得編造。產品依 D38 預設 OpenCode，這次 bootstrap 由協作者協調 Opus + GPT，不靠未完成的 controller 自動帶完。

只允許寫 /private/tmp/orca-controller-bootstrap-20260927/opus-session-design-02/outputs；不可修改 gigaxfer、orca-delivery 或全域設定，不做 git commit/push、GitHub 發文、產品程式碼實作、安裝、帳戶設定或模型推論測試，不另派 agents、不另啟外層 loop。不要因 session 開啟 bypass permissions 就擴張這個範圍。可讀檔與查本機 help；讀必要 skill 原文並保留觸發限制，方法未定就標建議，不假稱整套已核准。

交付到 outputs：
1. design.md：可實作的最小 controller 設計，包括狀態機、schema、版本／SHA失效、G1歷史Red/currentGreen、G2獨立性、required CI policies、finding lifecycle、file atomicity/concurrency/recovery、outbox/reconcile/idempotency、預算／timeout與native retries、adapters及選配runtime。比較合理方案、明示建議與待決，不改已確認policy。
2. tasks.md：依賴、scope、TDD行為測試、驗收、成果與整合策略；評估是否需拆可獨立交付PR，未定就提案。這是唯一正式 tasks 的候選草稿，不另造權威spec。
3. validation.md：覆蓋快照全部88個AC，以ID對映測法、環境、pass標準、證據位置；區分fake/真實runtime/GitHub/E2E，未執行明示。
4. result.json：對應run/task/attempt IDs、status(completed/blocked/failed)、實際讀取版本manifest、摘要、輸出參照、模型證據或缺口、至多3個真正阻擋決策、未決建議、驗證狀態。任務完成不代表gate通過。

上限30分鐘；遇無法查證的runtime/model能力就列未驗證及驗法，不臆造API、不卡在安裝。不重做完整SA，沿用已確認共識。完成後在console回報輸出路徑，供獨立GPT reviewer審查。具體design＋plan仍依D11交使用者確認，尚未授權寫產品程式碼。
