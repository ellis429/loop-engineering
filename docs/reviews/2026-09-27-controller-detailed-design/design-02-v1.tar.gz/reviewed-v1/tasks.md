# Tasks：implement-delivery-loop（唯一正式 tasks 候選草稿 design-02）

> 候選草稿，未經 D11 確認前不得派工。格式沿 OpenSpec `tasks.md`（`- [ ] X.Y`，驗法寫在同一行）；每個 task 下補 Writing Plans 要求的 Files／Interfaces／Red→Green（見 design.md §12 的適配差異）。
> 每個行為 task 遵守 Superpowers TDD：先寫失敗測試並以 `delivery evidence run --kind red` 保存（1.2 之前以 git commit＋原始輸出保存），再最小實作、Green、commit。所有路徑相對 orca-delivery repo。
> 測試層級：**F**=fake adapters（pytest，可離線）、**R**=真實 runtime、**GH**=真實 GitHub sandbox repo、**E2E**=完整交付。

## 整合策略與切片提案 [建議，待使用者決定：blocking decision B3]

D05 要求每個可獨立驗收 feature 一個 PR；本 change 含 4 個 capabilities，單一 PR 預估過大。提案切成 3 個 feature/PR（各自 issue，引用同一 OpenSpec change 作唯一規格，AC 子集如下）：

| 切片 | 內容 | 主要 AC | 驗收層級 | 前置 |
| --- | --- | --- | --- | --- |
| **S1 core** | 群組 1–2：store、ownership、outbox、budget、versions、gates、findings、狀態機、CLI（fake adapters） | 大部分 AC-D/G/F、AC-O 的 controller 部分 | F（V2＋V3） | D11、GitHub 目標、CI |
| **S2 adapters** | 群組 3–4：git/runner 真實化、GitHub、OpenCode、reviewer 隔離 | AC-D18–D24、G11–G15、G19、D12 real | R＋GH（V4） | S1 accepted＋merged（D27）、reviewer profile、OpenCode 登入 |
| **S3 orchestrate** | 群組 5：skill router、操作文件、E2E | AC-O16–O28、G20、A13 | E2E（V5） | S2 accepted＋merged |

替代方案：(a) 單一 PR：無 D27 等待，但 review 面積過大、單一 gate 失敗阻擋全部；(b) 4 個 PR（S1 拆 durable／gates）：review 更小，但多一次 D27 等待。建議 3 切片。

- 實作並行度 1（D13）；每個 task 一個 commit 序列（red → green → refactor），不 squash red 歷史（Red snapshot 另存 refs，squash 亦可追溯）。
- Bootstrap：controller 未完成前由協作者依同契約協調 Opus Implementer 與 GPT Reviewer；evidence 標 `coordinated_by=collaborator`。S1 完成後可用 `delivery gate eval` 對 S2/S3 做**非權威**的自我檢查，G2/G3 仍以獨立 reviewer 與真實 CI 為準。

## 0. 前置（非程式，D11 前後）

- [ ] 0.1 取得使用者對本 design/tasks/validation 版本（三檔 sha256）的 D11 確認，含 design.md 標 [建議] 的預設值；驗法：decision 紀錄指向三個 digests
- [ ] 0.2 確認 GitHub owner/repo、各切片 feature issue 與 required check 名稱；驗法：issue URL 可讀、`gh api repos/OWNER/REPO` 權限可讀
- [ ] 0.3 記錄 bootstrap Reviewer 的 provider/model 與派工通道（D39）；驗法：receipt 含 requested／actual model 或明列缺口

## 1. S1-A Durable foundation

- [ ] 1.1 建立 Python 3.12 專案骨架（uv、pytest、`delivery` entry point、CI workflow `test`）並驗證 `uv run pytest` 與 `delivery --help` 成功
  - Files：`pyproject.toml`、`src/delivery/__init__.py`、`src/delivery/cli.py`、`.github/workflows/test.yml`、`tests/test_cli.py`
  - Red：`test_cli_help_lists_commands` 在無 entry point 時失敗 → Green
- [ ] 1.2 Evidence runner `delivery evidence run`：捕捉 command/env allowlist/時間/exit/輸出 digest/junit/snapshot（`git stash create`＋`refs/delivery/red/...`）；驗法：`tests/test_runner.py` 通過
  - Interfaces：Produces `run_evidence(kind, task_id, attempt_id, argv, cwd) -> Evidence`
  - Red 測試：失敗測試產生 kind=red、failing IDs 正確；語法錯誤歸類 `collection_error`（AC-G07）；snapshot 含未提交測試檔；env 不含 allowlist 外鍵
- [ ] 1.3 原子 snapshot store＋schema 驗證＋手改偵測；驗法：`tests/test_store.py` 通過（AC-D01, D02, D09, D11）
  - Files：`src/delivery/store.py`、`src/delivery/schema.py`
  - Red：殘留 tmp 檔時讀到舊版完整 JSON；revision 衝突拒寫；未知 schema_version／壞 JSON → 明確錯誤且原檔不變；外部改 gate 為 passed → `manual_edit_detected`
- [ ] 1.4 events.jsonl pending history、ID 去重、尾筆截斷與中段損壞；驗法：`tests/test_events.py` 通過（AC-D10）
- [ ] 1.5 Write-once blobs 與 result 匯入（同內容去重、不同內容保留並 Blocked、身份不符拒收）；驗法：`tests/test_results.py` 通過（AC-D05, D07, D08）
- [ ] 1.6 Ownership：project 登記、主機 flock、唯讀模式、attempt 專屬 worktree/branch fencing；驗法：`tests/test_ownership.py` 以兩個 subprocess 同時 start 通過（AC-D03, D04）
- [ ] 1.7 Outbox 引擎：pending/in_flight/終態、marker 查回、unknown→Blocked、每 op 2 次額外重試；以 fake GitHub 注入回應遺失/5xx；驗法：`tests/test_outbox.py` 通過（AC-D12, D13, D16, F14）
- [ ] 1.8 Budget：active interval 聯集、crash unknown interval 全額計入、rounds 與 per-op retries 持久；驗法：`tests/test_budget.py` 通過（AC-D16, D17）

## 2. S1-B Gates、findings 與狀態機

- [ ] 2.1 `VersionSet`／`version_key`／失效矩陣；驗法：`tests/test_versions.py` 逐列驗 design.md §5 表（AC-G16, G17, D15）
- [ ] 2.2 G1 evaluator：Red 有效性、replay check、controller Green、lineage、adopt 缺 Red、N/A 預篩與 eligibility；驗法：`tests/test_gate_g1.py` 通過（AC-G04–G10）
  - Red 測試樣例：R 與 H 不同 SHA 且 lineage 成立 → passed；只有 green → missing；syntax red → invalid；task 綠但整合 regression 紅 → failed；設定檔宣告 N/A → 拒絕
- [ ] 2.3 G2 evaluator：profile/actual model 相符、session 獨立、isolation evidence、verdict 與 blocking findings；驗法：`tests/test_gate_g2.py` 通過（AC-G03, G11, G12, D24）
- [ ] 2.4 G3 evaluator：required 集合核對 repo rules、分頁、最新 attempt、app 來源、非成功狀態、merge-ref 映射；驗法：`tests/test_gate_g3.py` 參數化涵蓋 7 種非成功狀態＋skipped/neutral（AC-G13–G15）
- [ ] 2.5 Pass 判定與 re-read；驗法：`tests/test_pass.py` 通過（AC-G01, G02, G18）
- [ ] 2.6 Finding registry：配 ID、`matches` 沿用、blocking 分類、closure 權限；驗法：`tests/test_findings.py` 通過（AC-F01–F04）
- [ ] 2.7 Correction batch/rounds、一次 dispute、recurrence；驗法：`tests/test_correction.py` 通過（AC-F05–F10, F15, F16）
- [ ] 2.8 Decisions 與 acceptance：`delivery decide`、D11 綁版本、accept/return、scope change、budget extension；驗法：`tests/test_decisions.py` 通過（AC-O05–O07, O10, O11, F11, F12, D02）
- [ ] 2.9 狀態機與 adopt、依賴檢查（D27）、Project Lead 委派需授權來源；驗法：`tests/test_controller_flow.py` 以 fake runtime/GitHub 跑完整路徑（AC-O01–O04, O08, O09, O12, O13, O18, O19, O22, O23, O26）
- [ ] 2.10 Resume/reconcile：crash fixture（每個 crash 點的磁碟狀態）＋fake adapter 以 `os._exit` 模擬中斷的 subprocess 測試；驗法：`tests/test_resume.py` 通過（AC-D07, D09, D14, D15）
- [ ] 2.11 Publication 內容與 `delivery status`：PR 完整 review＋issue 摘要連結、status 顯示 phase/gates/blockers/next action；驗法：`tests/test_publication.py`、`tests/test_status.py`（AC-F13, F14, D01）
- [ ] 2.12 Retro operation 去重與 P03 guard（未明確開始不啟動）；驗法：`tests/test_retro.py`（AC-O14, O15）
- [ ] 2.13 S1 整合驗證：`uv run pytest` 全綠＋CI `test` 綠＋獨立 review；驗法：G1/G2/G3 evidence 保存於 `docs/validation/implement-delivery-loop.md` 引用位置

## 3. S2-A 真實 git 與 GitHub adapters

- [ ] 3.1 Git adapter 真實化（temp repo：worktree、ancestry、stash create、update-ref、ls-remote、push）；驗法：`tests/integration/test_git.py`（F 層，真 git）
- [ ] 3.2 GitHub adapter（`gh api`）：PR/comment/review/check-runs/statuses/rules，與 fake 共用 contract tests；驗法：`tests/contract/test_github_contract.py` 對 fake 通過
- [ ] 3.3 GitHub sandbox 實測：marker 查回、分頁、check attempt、required rules 讀取；驗法：`tests/integration/test_github_real.py -m gh` 在 sandbox repo 通過並保存 receipts（AC-D12, G13–G15, F13 real）

## 4. S2-B Runtime adapters 與 reviewer 隔離

- [ ] 4.1 Runtime contract tests＋第二個 fake runtime（驗 native identity 分離與能力報告不共用）；驗法：`tests/contract/test_runtime_contract.py`（AC-D21, D22）
- [ ] 4.2 OpenCode adapter：以 1.18.32 `/doc` 快照釘住 endpoints、preflight、model identity、原生 message 擷取；驗法：`tests/integration/test_opencode.py -m runtime` 實際推論通過（AC-D06, D18–D20, D23, D24）
- [ ] 4.3 Reviewer 隔離：獨立 clone、scrubbed env、事後 ref 核對；含「嘗試寫 author branch／push 應失敗」的實測；驗法：`tests/integration/test_isolation.py -m runtime`（AC-G11, G12, D19）
- [ ] 4.4 選配 adapters（Orca／Claude Code／Codex）：**僅在使用者選用時**建立；未選用則在 validation 標「未覆蓋」

## 5. S3 Orchestrate skill 與 E2E

- [ ] 5.1 `orchestrate` skill router＋references（project/feature/adopt-resume/retro），保留 user-only 限制並記錄 skill 版本；驗法：skill 載入測試＋文件審查清單（AC-O16, O17, O20–O28）
- [ ] 5.2 操作文件（README、runbook：start/resume/decide/status）；驗法：新 session 依文件從 `delivery status` 接續（V5）
- [ ] 5.3 E2E：在 orca-delivery 內一個小型真實 feature 走完 issue→design/plan→D11→TDD→PR→真實 review/CI→Pass；若 review 有成立 finding 則完成 fix→re-review，否則如實記未覆蓋；中途 kill controller 驗證不重派/重貼；驗法：run 目錄與 PR 連結（AC-G19, G20, A13）

## 自檢（Writing Plans self-review 的適配）

- Spec coverage：88 個 AC 皆映射至 task（見 validation.md）；AC-O20/O21/O24/O25/O27/O28 屬 Project Lead 分析行為，controller 只提供 5.1 的 skill 契約與 2.9 的 dispatch 拒絕，其餘靠文件審查/E2E。
- 未含 placeholder 測試碼：本草稿以測試名稱與斷言意圖描述 Red；D11 通過後，每個 task 於派工 assignment 內附完整測試碼（Writing Plans 的「No Placeholders」在 assignment 層落實）。這是相對原 skill 的明示調整。
