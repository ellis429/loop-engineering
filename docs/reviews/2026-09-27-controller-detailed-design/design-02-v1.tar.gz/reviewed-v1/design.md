# Design：implement-delivery-loop Controller（候選草稿 design-02）

> 狀態：Implementer（Opus 5.5）詳細設計草稿，供獨立 GPT reviewer 審查及 D11 確認。**不是已核准設計**，未授權產品程式碼。
> 輸入：`input-manifest.json` 的 15 份固定快照（hash 全部核對一致）。規格權威是同 change 的 `proposal.md` 與 `specs/`，本文件只寫 how；不重述 AC 內容，以 AC ID 引用。
> 標記：**[已定]** = 沿用已確認 D 決策；**[建議]** = 本設計提案，隨 D11 一次確認；**[待決]** = 需使用者回答或需實測。

## Context

- 已確認且本文不重開：三 gates（D01）、PR Pass 終點（D03）、單一 controller（D02/D08）、D09/D12 finding 規則、D13 上限（4h active、3 輪 correction、每項 infra 操作額外重試 2 次、實作並行度 1）、D14 JSON/YAML、D24–D28、D30/D38 runtime 解耦與 OpenCode 預設、D36/D39 本次由 Opus 5.5 Implementer + 獨立 GPT/Codex Reviewer 經協作者協調。
- 目前 orca-delivery 無 remote、無產品程式；OpenCode 1.18.32 只完成無推論 probe；精確 reviewer model、隔離、公司平台（Q-PLATFORM）、方法組合（Q-METHOD）未決。
- 本機可用：Python 3.12.13（uv）、OpenSpec 1.13.1、Superpowers 6.3.0、`gh`（登入可查帳號，未查目標 repo 權限）。

## Goals / Non-Goals

**Goals**
1. 一個確定性、可用 fake adapters 完整測試的 controller 核心：狀態機、gates、findings、budget、outbox、恢復。
2. 窄 adapters：git、evidence runner、GitHub（`gh api`）、runtime（OpenCode 預設；其他選配）。
3. 人可讀狀態：打開 `run.json` 或 `delivery status` 即可見 phase、gates 理由、blockers、next action（AC-D01）。

**Non-Goals**
- 不做 daemon/dashboard/DB/多主機 writer/共享網路磁碟支援（AC-D11 明示不宣稱）。
- 不自動 merge/close/release/deploy（D03）；不在背景呼叫 user-only skills（D28）。
- 不以 LLM 判定任何 gate 的確定性部分；語意判斷（測試是否有效證明 AC、finding 是否同一問題）只來自 Reviewer 結果或人工決策。
- 本次不實作 Orca/Claude Code/Codex adapters，除非使用者選用（D38 選配）。

## Decisions

### 1. 語言、形態與模組 [建議]

**選擇**：Python 3.12 本機 CLI `delivery`（uv 管理），核心只用 stdlib；唯一第三方依賴 PyYAML（只用 `safe_load`）讀 `workflow.yaml`。

| 方案 | 取捨 |
| --- | --- |
| **Python + stdlib + PyYAML（建議）** | 本機已有 3.12；`fcntl`/`os.replace`/`subprocess`/`json` 足夠；YAML 保留 D14 人可讀＋註解 |
| Python 零依賴、設定改 JSON | 少一個依賴，但失去設定註解，偏離 file-state 提案 |
| TypeScript/Node（貼近 OpenCode） | OpenCode 以 HTTP 接入，語言無關；無實質優勢 |

模組（依責任切分，一檔一責任）：

| 模組 | 責任 | 依賴 |
| --- | --- | --- |
| `store.py` | 原子 snapshot、鎖、write-once blobs、events.jsonl | stdlib |
| `schema.py` | run/assignment/result/evidence/operation/decision 的欄位驗證、`schema_version` | stdlib |
| `versions.py` | `VersionSet`、`version_key`、失效矩陣 | — |
| `gates.py` | G1/G2/G3 與 Pass 的**純函式**評估，輸出 status + reasons | versions |
| `findings.py` | registry 轉移、closure 權限、batch、dispute、recurrence | — |
| `budget.py` | active interval 聯集、unknown interval、rounds、per-op retries | — |
| `outbox.py` | operation 登記→執行→receipt→read-back、unknown 查回 | store |
| `controller.py` | `step(run, observations) -> (run', ops)` 狀態機；`reconcile()`；`resume()` | 以上 |
| `adapters/runtime.py` | runtime 協定＋`fake`、`opencode`（選配實作另檔） | — |
| `adapters/github.py` | `gh api` 包裝＋fake | — |
| `adapters/git.py`、`runner.py` | worktree/ancestry/snapshot；evidence 捕捉 | git |
| `cli.py` | `init/start/adopt/status/resume/decide/reconcile/preflight/evidence run/submit-result` | — |

核心規則全部在 `gates/findings/budget/versions/controller` 的純函式，I/O 只經 adapters 與 outbox，這是 fake 測試能覆蓋大多數 AC 的前提。Runtime 與 GitHub 協定至少各有 fake 與一個真實實作，不是單實作介面（D30 要求的正式接縫）。

### 2. 檔案布局 [建議，延伸 file-state.md]

```text
workflow.yaml                          # 版控：policy、required checks、profiles（無 credential）
.delivery/                             # gitignore；位於 repo 主 worktree
  project.json                         # feature→active run 指標、acceptance 紀錄、依賴
  runs/<run-id>/
    run.json                           # 唯一現行 authority（含 findings registry、operations、budget）
    events.jsonl                       # 稽核歷史
    assignments/<attempt-id>.json      # write-once
    inbox/<attempt-id>/result.json     # worker/adapter 寫入點
    results/<attempt-id>.json          # controller 驗證後的 write-once 副本
    evidence/<sha256>.json|.log        # content-addressed
    receipts/<op-id>/<n>.json          # 原生回應、read-back
$XDG_STATE_HOME/orca-delivery/locks/   # 主機層級 feature lock（見 §8）
```

`workflow.yaml` 範例（D13 上限寫死為常數，不做設定；只有未核准預設才放設定並隨 D11 確認）：

```yaml
schema_version: 1
repo: {github: OWNER/REPO, base: main}          # [待決] 目標 repo
g1:
  commands: [{id: unit, run: [uv, run, pytest, -q, "--junitxml={junit}"]}]
na: {doc_globs: ["docs/**", "**/*.md"]}          # 只作預篩，非豁免
ci:
  required: [{name: test, app: github-actions}]  # 須與 repo rules 核對
  allow_non_success: []                          # 例：{name, conclusions:[skipped], decision: DEC-..}
timeouts_min: {worker: 45, review: 30, ci: 30}   # [建議] 未核准預設
recurrence: {max_failed_rechecks: 2, block_on_reopen: true}   # [建議]
profiles:
  implementer: {runtime: opencode, provider: anthropic, model: claude-opus-5-5}
  reviewer:    {runtime: opencode, provider: openai, model: null, isolation: clone_scrubbed_env}  # [待決] model
```

### 3. 狀態機 [建議；phase enum 沿用 workflow-contracts]

維度分開保存（contracts「狀態分開保存」表）：phase、task execution、gate、review verdict、publication、human acceptance、integration facts。另加 `waits[]`（非 Blocked 的等待理由，如 dependency、CI pending）與 `blockers[]`（原因、證據、需誰決定、最小恢復條件）。

| From | 事件／guard | To |
| --- | --- | --- |
| intake | 新 feature 或 adopt 缺 design/plan | planning |
| intake | plan 存在但無該 `plan_version` 的 D11 decision | awaiting_approval |
| intake(adopt) | D11 適用、tasks 未完 / 已實作 G1 待驗 / G1 已核對 | implementing / validating / checking（AC-O08） |
| intake | owner 未交接、未知 writer、必要來源不可讀或衝突 | blocked（AC-O04, O09） |
| planning | C3 package 登記（design/tasks/validation digests、task→AC） | awaiting_approval |
| awaiting_approval | `approve_plan` decision 指向**目前** plan version，且 ticket、依賴（D27）、budget 通過 | implementing（AC-O05, O06, O13） |
| awaiting_approval | `revise` decision | planning |
| implementing | 下一 task 依序派；全部 task succeeded 且已整合 | validating |
| validating | G1 passed → 確保 push 與 PR（outbox） | checking |
| validating | G1 可修補缺失 | 回到產生該版本的工作單位（implementing 或 correcting），**不**新增 round |
| validating | 歷史 Red 不可得、N/A 被拒且無法補、red 不可重現 | blocked（AC-G07, G10） |
| checking | 同一 `version_key` 的 G2 結果與 G3 終態收齊，三 gates passed，Pass 前 re-read 一致 | ready_for_acceptance（AC-G01, G18） |
| checking | 收齊且有可修問題、rounds<3、未觸發 recurrence | correcting（AC-F05） |
| checking | verdict=blocked、爭議未解、rounds 用盡、unknown 無法恢復 | blocked（AC-G03, F07, F09） |
| correcting | correction result 完整（每個 finding 皆有回應）且產生新 head | validating（AC-F06, F10） |
| ready_for_acceptance | `accept` decision（綁 version） | 同 phase，acceptance=accepted → 登記 Retro op（AC-O14） |
| ready_for_acceptance | `return` decision：原 AC 缺陷且預算足 | correcting（AC-F11） |
| ready_for_acceptance | 新 head/base/spec 等變更 | 依 §5 失效矩陣回 validating/checking/awaiting_approval（AC-O11, G18） |
| 任一 | 4h active 到限、ownership 衝突、state 不可信 | blocked（AC-D17, D11） |
| blocked | `unblock` decision 或外部條件恢復（resume 重評） | 依 blocker 的 `resume_to` |

`step()` 是純函式：輸入 run snapshot＋觀察（adapter 讀回的事實、已匯入 results、decisions），輸出新 snapshot＋待登記 operations。所有副作用只在 snapshot 提交後由 outbox 執行（§9）。

### 4. Schema 要點 [建議]

所有 JSON 帶 `schema_version`；未知版本 → Blocked（AC-D11）。`run.json` 頂層順序以人讀為先：

```json
{
  "schema_version": 1, "run_id": "r-…", "revision": 42,
  "phase": "checking", "next_action": {"kind": "wait_ci", "detail": "test pending (attempt 2)"},
  "blockers": [], "waits": [{"kind": "ci", "since": "…"}],
  "versions": {"version_key": "sha256:…", "set": {"…": "見 §5"}},
  "gates": {"g1": {"status": "passed", "version_key": "…", "reasons": [], "evidence": ["sha256:…"]},
            "g2": {"status": "pending", "…": "…"}, "g3": {"status": "pending", "…": "…"}},
  "acceptance": {"status": "pending", "version_key": null, "history": []},
  "budget": {"active_seconds": 5400, "open_activities": [], "unknown_intervals": [],
             "correction_rounds_used": 1, "infra_retries": {"op-17": 1}},
  "feature": {"repo_id": "github:OWNER/REPO", "feature_key": "OWNER/REPO#12", "pr": 34},
  "approval": {"decision_id": "DEC-3", "plan_version": "sha256:…"},
  "tasks": [{"task_id": "2.3", "ac_ids": ["AC-G11"], "change_class": "behavior",
             "status": "succeeded", "attempts": ["a-…"], "red": ["sha256:…"], "commits": ["…"]}],
  "findings": {"F-0001": {"…": "見 §7"}}, "batches": [], "disputes": {},
  "operations": {"op-17": {"…": "見 §9"}},
  "imported_results": {"a-…": "sha256:…"},
  "decisions": ["DEC-3"], "pass_history": [], "pending_history": []
}
```

- **Assignment**：contracts 欄位全數保留；另含 `profile`（entry/transport、runtime+version、provider、requested_model）、`marker`（= attempt_id，用於 lookup）、`result_path`、`deadline`。
- **Result**：同 IDs、`execution_status`（succeeded/failed/blocked）與 `verdict`（僅 review）分開、`observed`（cwd、head、base、artifact digests）、`evidence[]`、`findings[]`、`responses[]`（correction：每個 finding 的 `fix_submitted`/`disputed`）、`producer`（agent 或 adapter＋native session/message IDs＋actual_model）。
- **Evidence**（runner 產出）：`task_id/ac_ids/attempt_id`、`kind`（red/green/regression/doc_check/replay_check）、`command`、`env`（allowlist 鍵與值，不含 secret）、`started_at/ended_at`、`exit_code`、`stdout/stderr` blob digest、`junit` 摘要（failed test IDs、collection errors）、`snapshot`（commit + tree）、`producer`（`delivery-runner` 版本＋host）。
- **Decision**：`decision_id`、`kind`（approve_plan/revise/accept/return/resolve_finding/waive_finding/budget_extension/unblock/handoff/policy_change）、`subject`（IDs＋version_key）、`actor`、`source`（對話/訊息參照）、`choice`、`reason`、`created_at`、`impact`。只能經 `delivery decide` 寫入並驗證 subject 版本（AC-D02）。

### 5. 版本與失效 [建議；集合沿用 GAT-07]

`VersionSet` = repo_id、pr、head_sha、base_ref、base_tip、merge_base、`spec_digests`（project/feature spec 檔、issue body digest＋observed_at）、design/plan/validation digests、policy digest（`workflow.yaml` 正規化後）、skill digests、controller version。`version_key` = 其 canonical JSON 的 sha256。每個 gate 結果、review、CI 觀察、Pass、acceptance 都存 `version_key`。

| 變化欄位 | 動作 |
| --- | --- |
| head | g1/g2/g3 → stale；歷史 Red lineage 保留；→ validating（AC-G16） |
| base_tip / merge_base | g2 → stale（重建 diff）；g3 依 check 綁定判斷（綁 merge ref 者 stale）；g1 保留 → checking（AC-G17） |
| spec/design/plan/validation digest | 控制器無法判斷語意是否需 D11 → **一律** awaiting_approval，顯示 diff；decision 可附 `reuse` 理由沿用特定 evidence（AC-G17, O07） |
| policy digest | 以新 policy 重算；若任一 gate 由非通過轉通過**只因** policy 變更 → Blocked 待 `policy_change` decision（「不能只改規則消除 blocker」） |
| skill/controller version | 記錄並提供 Reviewer；核准 plan 釘住的 skill digest 缺失或改變 → 不派該 assignment，Blocked |
| 晚到結果（version_key ≠ current） | 保存為歷史，不評入現行 gate，不重置 findings/budget（AC-G16） |

Pass 前 re-read（head/base/artifact digests）；不一致就放棄轉移並 reconcile；Pass 記錄帶 `observed_at`，不宣稱全域 transaction（AC-G18）。Acceptance 綁 version_key；新版本 acceptance 重新 pending（AC-O11）。

### 6. Gates

#### G1：歷史 Red＋目前 Green [建議]

- **Red 捕捉**：worker 以 `delivery evidence run --kind red -- <cmd>` 執行；runner 用 `git stash create`（無變更則 HEAD）取得含未提交測試的 snapshot commit，存於 `refs/delivery/red/<run>/<task>/<attempt>` 防 GC，記 tree、junit 與 digests。Branch 可自由整理，Red 仍可追溯。
- **Red 有效性（確定性）**：blob 存在且 digest 符合、producer=runner、exit≠0、junit 有 failure 且 **0** collection/usage error（否則歸 invalid：語法/環境錯誤，AC-G07）、snapshot 的起點 commit 是目前 head H 的祖先（lineage）、failing test IDs 在 H 的 Green 中存在且通過。
- **Replay check [建議，always-on，不做開關]**：controller 在自有 verification worktree 於 Red snapshot 重跑同命令，須再次以相同 test IDs 失敗；標為 `replay_check`，只佐證、不冒充原始紀錄。無法重現（環境/flaky）→ G1 unknown → Blocked 待決。代價：多跑一次測試；換來偽造 red log 無法單獨通過。
- **Green**：controller 在乾淨 checkout of H 執行 `g1.commands`（含完整 regression），evidence producer=controller-runner。Task worktree 成功不算數（AC-G08）。實作並行度 1，task commits 直接在 feature branch 上，task→integration lineage 即 git ancestry。
- **Adopt 無歷史 Red**：G1=missing → Blocked；只有 decision 明示接受 replay 替代時，gate reason 記 `red_source=replay_by_decision`（AC-G07, O09）。
- **N/A eligibility**：task 標 `na_requested`＋理由 → controller 預篩（變更路徑 ⊆ `na.doc_globs`，否則直接拒絕）→ 派獨立 Reviewer 的 eligibility assignment（與 G2 同隔離規則），結果綁 diff digest。接受只免該 task 的 Red/Green 要求；`g1.commands` 仍在 H 執行，G2/G3 照常（AC-G09, G10）。
- G1 輸出：`passed | failed | missing | unknown | stale`，逐 task 列 reasons（AC-G04）。

#### G2：獨立 review [建議；isolation 能力待實測]

G2 passed 需同時成立：
1. Reviewer assignment 由 controller 建立（role=reviewer），profile 符合 `profiles.reviewer` 的核准 provider/model；native 回報 actual model = requested（AC-D18, D24）。
2. 獨立性證據：reviewer session ID ≠ 任何 implementer session，且非其子 session（OpenCode session 是否帶 parent 欄位**待以 /doc 核對**）。
3. 隔離證據 `isolation.status = verified`：
   - **工作區**：`git clone --no-hardlinks` 到獨立目錄並 checkout 固定 head（不是 worktree，不共享 refs）；reviewer 可在自己 clone 內跑測試。
   - **憑證**：reviewer runtime 以獨立 process 啟動，env 移除 GitHub token、HOME 指向空設定目錄；controller 才持有發文權限。
   - **事後核對**：review 完成後 author branch ref 與 remote ref 未變、feature worktree `git status` 未被 reviewer 改動。
   - 三者任一無證據 → `isolation.status=unverified` → G2 unknown、Blocked 並列能力缺口；不因「禁用 edit 工具」宣稱安全（AC-G12, D19）。
4. Verdict=clean 且 `version_key` 為目前版本、所有 blocking findings 已依 §7 closure（AC-G11）。
Verdict=blocked → G2 unknown、phase blocked，不開 correction round（AC-G03）。Implementer 呼叫的 subagent review 永不匯入 G2（AC-G12, O02）。

**本次 bootstrap（D39）**：Reviewer 由協作者手動協調 GPT/Codex，controller 尚不存在；該 review 的獨立性以協作者保存的 assignment/receipt 為證，不冒充產品 G2 實測。

#### G3：必要 CI [建議]

- Required 集合 = `ci.required`；controller 讀 repo 的 branch protection／rulesets（`gh api`）核對：集合為空、repo rules 不可讀、或兩邊不一致 → G3 不通過（unknown/failed 並列原因），Blocked 待 `policy_change` 決策（AC-G13）。
- 每個 required `(name, app)`：取 head SHA 的 check-runs（`filter=all`、完整分頁）與 commit statuses；只接受 app 相符者；同名多 attempt 取最新（依 `started_at`，平手依 id）；舊 success 不蓋新 attempt（AC-G14）。
- 判定：completed + conclusion∈{success} 才過；skipped/neutral 僅在 `allow_non_success` 有對應 decision 時接受；missing/pending/cancelled/timed_out/failure/unknown/stale 逐項列原因。
- 衍生 snapshot：check 的 SHA ≠ head 時，只有 adapter 以 git 驗證該 commit 的 parents = [base_tip, head]（merge ref）才採用，否則 stale/unknown（AC-G15）。
- CI 等待 > `timeouts_min.ci`：以 rerequest 作為 infra 操作（≤2 次額外重試），用盡 → Blocked（AC-D16）。

#### Pass

三 gates 皆 `passed` 且同一 `version_key`、無未解 blocking finding、Pass 前 re-read 一致 → 寫 `pass_history` 並產生 PR Pass package（版本、三 gates 理由與 evidence、findings、限制、publication 狀態）（AC-O10）。Task succeeded、通知、idle、input_accepted 永不進入 gate 計算（AC-G01, G02）。

### 7. Finding lifecycle [建議；權威與權限為已定]

欄位：`id`（controller 配發 `F-0001`）、`source`（reviewer/ci/human_acceptance）、`severity`、`blocking`、`location`、`problem`、`basis`、`expected`、`status`、`fix_commits`、`rechecks[]`、`dispute`、`closure`（actor/source/version/reason/evidence）、`lineage`（reopen_of、先前 IDs）。

```text
open ──fix_submitted──> fix_submitted ──reviewer recheck ok──> resolved
  │                          └──recheck still failing──> open (failed_rechecks+1)
  ├──disputed──> disputed ──一次獨立覆核接受──> resolved
  │                   └──覆核維持──> dispute_upheld → Blocked（不重派第二次）
  ├──human waive/resolve decision──> waived / resolved
resolved ──reviewer 以依據標為同一缺陷再現──> reopened → open（reopen_count+1）
```

- Closure 只接受：目前版本的 Reviewer 結果，或指定 finding＋版本的人工 decision。GitHub thread resolved、approve 按鈕、Implementer 宣告都只是事件（AC-F03, F04）。
- Identity：Reviewer 收到舊 findings 清單，需以 `matches: F-000x` 指認同一問題；未指認者配新 ID。Controller 不以位置或文字相似自動合併（AC-F02, F16）。
- Blocking：Reviewer 提供 `blocking` 與依據類別（spec/AC、正確性/安全、必要驗證缺失、偏好）；類別為偏好者不得標 blocking（AC-F01）。
- Correction batch：checking 收齊同版本 G2/G3 後建立唯一 batch（findings、CI failures、scope、AC、驗法）；**派修 operation 登記時** round+1。Result 缺任一 finding 回應 → 不完整，不解除任何 finding（AC-F05–F07）。
- Dispute：每個 finding 至多一次覆核，計數存 `disputes[finding_id]`，restart/重送不重置；覆核不增 round；伴隨新 head 時先過 G1 再合併最新 review（AC-F08–F10）。
- Recurrence [建議預設]：`failed_rechecks ≥ 2` 或任一次 `reopened` → 下次派修前 Blocked（AC-F15, F16）。重複通知/同 result 重送/infra retry 不計數。
- 人工退回：`return` decision → finding `source=human_acceptance`，以來源 identity 去重，失效 Pass，沿用同 run 剩餘 rounds（AC-F11）；scope 外或 spec 錯誤 → Blocked 交 Project Lead/使用者（AC-F12, O07）。

### 8. 檔案原子性、並行與恢復 [建議；POSIX 範圍]

- **Snapshot**：同目錄 tmp → write → `fsync`（macOS 另用 `F_FULLFSYNC`）→ `os.replace` → fsync 目錄。讀者只見完整舊或新版（AC-D09）。
- **外部手改偵測**：載入時記 file digest；提交前在 run lock 內比對，不符 → 事件 `manual_edit_detected`，以 schema 驗證後**從 evidence＋decisions 重算** gates（gates 儲存值只是含理由的快取），不把手改值當決策（AC-D02）。
- **Write-once blobs**：assignments/results/evidence/receipts 以 `os.link(tmp, final)` 建立（已存在即失敗）。Inbox 結果首次匯入時複製並記 digest；同 attempt 不同 bytes → 保留雙方為 `*.conflict-<sha>.json` 並 Blocked；相同 bytes → 僅喚醒 reconcile（AC-D07, D08）。
- **Events**：`pending_history` 隨 snapshot 提交，之後 append 並 fsync，再於下一版清除；resume 以 event ID 去重補寫；尾筆殘缺 → 複製診斷檔並截至最後完整換行；中段損壞或同 ID 不同內容 → Blocked（AC-D10）。
- **Ownership（三層）**：
  1. `project.json` 的 feature→active run 登記：非終態 run 存在時，`start` 另一 run 被拒並顯示現有 owner（AC-D03）。
  2. 主機層級 feature lock：`$XDG_STATE_HOME/orca-delivery/locks/<sha256(repo_id+feature_key)>.lock` 以 `fcntl.flock(LOCK_EX|LOCK_NB)` 持有至 process 結束，另寫 holder 資訊；失敗者進入唯讀模式。Repo identity 用 GitHub `owner/repo`，無 remote 時用 git common dir 的 realpath，避免兩個 clone 各自控制。
  3. Worktree writer lease：每個 attempt 使用專屬 worktree＋branch `delivery/<run>/<task>/<attempt>`；workers **不持有 push 權限**，controller 只整合目前 lease 的 attempt branch。Timeout/unknown 時先請 adapter stop 並確認；無法確認時，fencing 證據 = 新 attempt 使用新 worktree/branch＋舊 attempt 的 result 以 attempt_id 拒收＋舊 branch 永不整合。預設仍要求 stop 已請求並記錄；stop 狀態 unknown 且使用者未以 decision 接受 fencing 時保持 Blocked（AC-D04）。
- **Resume 順序**（AC-D14, D15）：取 lock → 載入並驗 schema（失敗→Blocked，不建空 run）→ 補寫 pending history → 將 `in_flight` operations 標 `outcome_unknown` → 讀外部實況（workers、PR head/base、checks、inbox、outbox markers）→ 匯入新 results → 重算 versions 與 gates → 只接續最小必要工作；不把 tasks 重設 pending。Project 指標在 run reconcile 後修復（DUR-07）。
- **信任限制（誠實列出）**：workers 與 controller 同一 OS 使用者時，技術上可寫 `.delivery/`；MVP 只能**偵測**（digest 比對、decision 必附 source、Pass package 列出所有 decisions 供人複核），不能**防止**。OS 層級防護（不同 UID/sandbox）列入 Q-PLATFORM 與 runtime 隔離驗證。

### 9. Outbox、reconcile、idempotency [建議]

Operation：`op_id`、`kind`（dispatch/push/pr_create/pr_comment/issue_comment/rerequest_ci/stop/retro）、`target`、`payload_digest`、`marker`、`depends_on`、`state`（pending→in_flight→succeeded|failed|outcome_unknown）、`attempts[]`（receipt ref）、`retries_used`、`readback`。

1. `step()` 產生 op → snapshot 提交（pending）。
2. 執行前再提交 `in_flight`；crash 後 resume 一律視為 `outcome_unknown`。
3. 呼叫 adapter → 存 receipt → read-back → 提交終態。
4. **任何**失敗或 unknown 先以 marker 查回：找到 → succeeded（AC-D12）；確定不存在 → 在 D13 預算內重試；查詢本身失敗 → 計入同一 op 的重試，用盡 → Blocked 並保存查詢證據（AC-D13）。

| 操作 | Marker 與查回 |
| --- | --- |
| GitHub comment／review | 內文 `<!-- orca-delivery op=<op_id> run=<run_id> result=<result_id> -->`；列出全部分頁比對 |
| PR 建立 | body marker＋以 head branch 查 PR |
| Push | `git ls-remote` 比對 remote ref 是否已為目標 SHA |
| Dispatch | marker=attempt_id 寫入 session title 與首則訊息；以 runtime 的 session 列表查回（OpenCode 列表能力**待核對**） |
| Retro | marker=acceptance decision ID＋version_key；同 identity 只登記一次（AC-O14） |

Publication 與 verdict 分離：先保存 review → pr_comment op → issue_comment op（`depends_on` PR comment read-back 的 URL）。發文失敗只重試該 op，不重做 review（AC-F13, F14）。通知／事件串流只觸發 reconcile，不承載狀態（AC-D07, D21）。檔案 store 不宣稱外部 exactly-once。

### 10. 預算、timeout 與 native retries [D13 已定；算法為建議]

- **Active time**：記錄活動區間（worker attempt running、CI wait、controller operation in_flight），`active_seconds` = 區間聯集長度，不因並行重複計（contracts 提案）。等待人工（awaiting_approval、blocked、acceptance pending）且無活動時不計；已派出的 worker 仍計。
- **Crash 間隔**：resume 時，崩潰前開啟的活動區間 `[last_persisted_at, resume_at]` 記為 unknown 並**全額計入**；只有所有開啟活動都有外部結束時間（result 的 ended_at、check 的 completed_at）才截至其最大值（AC-D17）。
- **到限**：停止新派工 → 對存活 workers 發 stop op 並確認 → 保存 Blocked（含 unknown intervals）。延長只能經 `budget_extension` decision；新 run ID 不重置（`project.json` 以 feature 累計）。
- **Timeout**（45/30/30 min，未核准預設）：到期 → 查 status → 請求 stop → 確認停止才算一次 infra 失敗並在 ≤2 次額外重試內重派；status unknown → Blocked（AC-D04）。
- **Infra vs correction**：runner 或 adapter 能分類的程式/測試失敗（junit failures、review changes_required）走 correction；只有傳輸、逾時、服務不可用走 infra retry（AC-D16）。
- **Native retries**：runtime/CLI 內建重試（Claude Code API retries、OpenCode provider retries、`gh` 的傳輸重試）屬於**單一** controller 操作 attempt 內部，不計入 D13 次數，但其 wall-clock 計入該操作 timeout 與 active time。Adapter 在 receipt 記錄可得的 native retry 次數；可設定上限者設為有限值以免與外層重試相乘。各 runtime 的 native retry 行為**未驗證**，列入 adapter preflight 實測。

### 11. Adapters 與選配 runtime [D30/D38 已定；介面為建議]

Runtime 協定（核心只依賴此協定）：

| 能力 | 用途 | 失敗語意 |
| --- | --- | --- |
| `preflight(profile)` | 版本、認證可用（不輸出值）、model 可用、工具權限、workspace placement、結果通道 | 具體 capability 缺口 → Blocked（AC-D19） |
| `dispatch(assignment)` | 建立獨立 session 並送出 prompt，回 native handles | 只有 accepted 不算成功（AC-D18） |
| `lookup(marker)` | outbox 查回 | — |
| `status(handle)` | running/idle/stopped/unknown＋證據 | idle ≠ completed |
| `collect(handle)` | 原生 messages 原文、actual model、usage | 缺 result 檔時 adapter 從最後 assistant message 擷取結構化 JSON，producer 記 adapter（AC-D06） |
| `stop(handle)` | 中止並回報確認 | 無法確認 → unknown |

- **OpenCode（預設）**：controller 為每個角色啟動獨立 `opencode serve`（localhost、隨機 Basic auth、角色專屬 env/cwd），以 HTTP 呼叫。所需操作：health、建立 session、以 `{provider, model}` 送 prompt、列 messages、abort、列 sessions。**具體路徑與欄位必須從 1.18.32 的 `/doc` 快照釘住，本設計不假設 path**；actual model 是否出現在 assistant message metadata 待核對。
- **選配**：Orca（worker-start `--model`、worker-read）、Claude Code（print/stream-json）、Codex CLI 只在 profile 選用時載入與 preflight；未選用者缺失不影響（AC-D20, D23）。Native IDs 放 `attempt.native`（自由結構），核心 identity 為 run/task/attempt（AC-D21）；各接法 capability 報告分開保存（AC-D22）。
- **GitHub**：`gh api` subprocess，JSON 輸出；分頁一律取完。Fake 支援：回應遺失、5xx、分頁、多 attempt、未知 app。
- **Git／runner**：worktree、ancestry、`stash create`、`update-ref`、`ls-remote`、push（僅 controller）。

### 12. 方法與 skills 接合 [Q-METHOD 候選，建議]

- 本 tasks.md 採 OpenSpec `tasks.md` checkbox 格式作**唯一** plan；每個 task 補 Writing Plans（Superpowers 6.3.0，SKILL.md sha256 `48508f44…`）要求的 Files、Interfaces、Red/Green 步驟與驗法。**差異明示**：不使用其預設路徑 `docs/superpowers/plans/`；其 Execution Handoff（subagent-driven-development／executing-plans）**改由 controller 或 bootstrap 協作者派工**，不原封啟動另一個 loop；OpenSpec apply 只能以指定 task IDs 受限呼叫。
- TDD 採 Superpowers test-driven-development（D26 已定，SKILL.md sha256 `bf1b8216…`）；其「設定檔可例外」條款不適用本 repo 規則，豁免只走 N/A eligibility。
- `orchestrate` skill 為薄 router，呼叫 `delivery` CLI；user-only skills（Matt to-spec/to-tickets/retro/grill-with-docs）不在背景呼叫，Retro 用明示整合 reference（D28）。

## Risks / Trade-offs

- [同 UID 可偽造 state/evidence] → digest 偵測＋Red replay＋controller 自跑 Green＋decisions 需 source 並列入 Pass package；OS 隔離列待決。
- [Red replay 在環境相依測試上無法重現] → G1 unknown 交人裁決；代價是偶發 Blocked，換取偽造 log 無法通過。
- [spec/design 任何 digest 變更都回 awaiting_approval] → 較多人工確認；換取 controller 不做語意判斷。可由 decision 的 `reuse` 快速沿用。
- [flock 只保證單主機] → 不支援多主機/網路磁碟，明示（AC-D11）。
- [切成多個 PR 受 D27 約束：下游須等上游 accepted＋merged 才實作] → 等待期可準備 spec/design；見 tasks.md 切片提案。
- [OpenCode API、actual model 欄位、session 父子關係、隔離皆未實測] → PR 切片中獨立的 real-adapter 驗證 task，未通過就如實 Blocked，不以 fake 成功替代（AC-G19）。
- [bootstrap 期間 controller 不存在] → 協作者依相同契約手動協調，證據標 `coordinated_by=collaborator`，與 controller 自動執行區段分開。

## Migration Plan

新 repo 內新增程式，無既有資料遷移。`schema_version=1` 起算；後續 schema 變更需 migration 函式與測試，resume 遇未知版本 Blocked。回滾 = 不使用 controller（狀態檔為人可讀，保留為紀錄）。

## Open Questions

真正影響開工的三項列於 `result.json.blocking_decisions`（D11 確認本版本及其建議預設、GitHub 目標與 required checks、PR 切片）。其餘可延後而不改變本設計結構：

- Reviewer 精確 provider/model 與隔離實測結果（影響 `profiles.reviewer` 值，不改 G2 規則）。
- Q-PLATFORM：本設計以 macOS/Linux POSIX 為範圍；Windows/WSL2 需另驗鎖與 rename。
- OpenCode endpoints、actual model 欄位、session 列表/父子關係與 native retry 設定（以 `/doc` 與推論 probe 釘住）。
- Recurrence 門檻、timeout、skipped/neutral 例外清單的實際值（本文給建議預設，隨 D11 確認）。
