# Orchestrate：整體 Workflow Design v1

日期：2026-09-26。狀態：供使用者 review 的整合設計，尚非已安裝 skill、controller 或批准開工的 implementation plan。

本文是最新整體設計入口。[decisions.md](decisions.md) 記錄已確認政策；[先前討論草案](orchestrate-workflow-draft.md) 保留來源比較與推導；執行契約見 [workflow-contracts.md](workflow-contracts.md)。建議與未決事項不因寫入本文就成為已核准政策。P03 Retro 等使用者開始；PR gating 試用仍依 D18 暫緩。

## 1. 一個入口、兩個層級

使用者透過 `orchestrate` 與目前角色協作。這是 skill 的擬議使用語意，不是已存在的 CLI：

| 意圖 | 載入哪段流程 | 第一個可驗證結果 |
| --- | --- | --- |
| 建立／接手 project | Project intake，判斷 greenfield / brownfield | Repo、project artifacts、已決定與待決事項的入口 |
| 準備下一個 feature | Project Lead 讀 roadmap、依賴與已驗收成果 | 可交付 slice 的 spec / high-level design / ticket |
| 開始指定 feature | Feature start | 適用 baseline、需求、design / plan 及 AC 驗法 |
| 接入既有 feature / PR | Adopt | 唯讀查核與證據缺口；確認原 owner 交接後才派工 |
| 查進度／恢復 | Status / resume | 真實 head、workers、gates、待發文與下一個允許 action |
| 處理 Blocked | Decision | 對指定版本、問題與理由的人工裁決 |
| 對指定 feature 做 Retro | Retro | 有證據的改善候選；未涵蓋階段明列 |

Project loop 管理方向與交付順序；feature loop 完成單一 PR。每個 feature 同時只有一個 controller 擁有派工權。Skills 提供方法，agents 提出語意判斷，controller 執行版本、狀態、gate 與限制規則。

| 層級 | 主要協作者 | 管理範圍 | 與另一層的交接 |
| --- | --- | --- | --- |
| **Project Loop** | 使用者 + Project Lead Agent | Mission、共用規格與架構、roadmap、feature 準備、人工驗收、Retro / Replanning | 交出 feature spec / AC、high-level design 與 ticket；接回 PR Pass package 供驗收 |
| **Feature Loop** | Implementer Agent + Reviewer Agent；使用者確認開工與裁決歧義 | Detailed design / plan、TDD tasks、整合 PR、review / CI、fix / re-review | 引用 project baseline；通過三 gates 後交回 PR Pass package |

交接順序是 **Project 準備 feature → Feature 交付 PR Pass → Project 人工驗收、Retro 並準備下一個 feature**。Review / fix 留在 Feature Loop；跨 feature 的改善與 Replanning 回到 Project Loop。這是兩個工作層級，共用 `orchestrate` 入口，不為同一 feature 建立兩套派工 loop。


## 2. 角色與控制權

依 D23，Project Lead、Implementer、Reviewer 是同層協作角色。Project／Feature 表示工作範圍；使用者可透過共同 `orchestrate` 入口直接與任一角色協作。Project Lead 與 Implementer 以 feature spec／AC、依賴及交付成果交接，不要求每項 feature 工作都先經 Project Lead 轉達。

使用者直接交付已確認的 feature 時，Implementer 可進入 design／plan；遇到跨 feature 影響，由 Project Lead 協助分析，再交使用者決定。只有使用者明確授權代理安排時，Project Lead 才在指定範圍內安排優先順序與日常協作；其角色名稱本身不授予 scope 變更、開工批准或最終接受權。

角色間的交接仍由唯一 controller 依核准 plan 派工及收取結果。使用者直接與 Reviewer 討論不等於已完成 G2；正式 review 仍須符合獨立 assignment/session 與證據契約。Controller 是執行協調機制，不是 agents 的主管。

| 角色 | 決定／負責 | 交出什麼 |
| --- | --- | --- |
| 使用者 | 產品取捨、選定 feature、重要需求／架構歧義、design + plan 開工確認、爭議裁決、最終接受 | 具適用版本的明確決策 |
| Project Lead Agent | Research / grill、project 共用規格與架構、roadmap、準備 feature、協助驗收及 Retro | Feature brief、baseline 引用、人工待決事項 |
| Implementer Agent | Feature detailed design / plan、task 依賴與整合、TDD 實作與修正，統籌自身 implementation subagents 的工作內容 | Code、tests、結果與版本化 evidence、PR Pass package |
| Reviewer Agent | 獨立 Codex review：spec 與 quality、測試有效性、舊 finding 覆核與新問題 | Verdict、穩定 findings、覆核證據 |
| Controller | 唯一派工、收結果、核查 gates、持久化、預算、恢復、發布與通知 | 可讀 run state、operation receipts、Pass／Blocked 依據 |

Implementer 可以提出派工與修正批次；controller 依核准 plan、依賴、scope 與預算執行，不讓 Implementer 的 skills 再啟動第二套外層排程。Project Lead 可準備候選需求，但不越過當前 feature owner 同時派修。

Reviewer 在隔離環境讀碼與驗證，結果／logs 可寫入指定位置；被審查 branch 不可修改。Controller 另負責 GitHub 發布，reviewer 不必持有寫入 GitHub 的權限。G2 的 Reviewer Agent 由 controller 以獨立 assignment、獨立 session 派出；不得由 Implementer 透過 opencode Task tool、Claude subagent 等方式呼叫。Implementer 在 task 內使用的 review subagent 可保留作局部品質檢查，不能取代最終整合 PR 的獨立 G2。

## 3. 完整路徑

```mermaid
flowchart TD
    subgraph PROJECT[Project Loop：使用者 + Project Lead Agent]
        A[Project intake 與 research] --> B[與使用者建立需求／架構／roadmap]
        B --> C[確認 Phase 0 基礎]
        C --> D[使用者選 feature，準備 spec／AC／ticket]
        P[使用者與 Project Lead 驗收] -->|接受| Q[自動整理 Retro 改善候選]
        Q --> R{需要 Replanning}
        R -->|需要| B
        R -->|不需要| S[依相依政策準備下一個 feature]
        S --> D
    end

    subgraph FEATURE[Feature Loop：Implementer Agent + Reviewer Agent]
        E[Implementer 詳細設計／plan／驗法] --> F{使用者一次開工確認}
        F -->|修改| E
        F -->|確認| G[TDD tasks 與整合]
        G --> H{G1 證據適用且通過}
        H -->|可補的缺失／失敗| G
        H -->|無法取得歷史 Red／N/A 待裁決| X[Blocked：證據與待決事項]
        H -->|通過| I[建立／更新或核對 feature PR]
        I --> J[G2 獨立 Reviewer]
        I --> K[G3 必要 CI]
        J --> L[收齊同一版本結果]
        K --> L
        L --> M{三 gates 通過}
        M -->|可修正| T{同一 run 修正預算尚足}
        T -->|是| N[合併修正批次]
        T -->|到限| X
        N --> G
        M -->|通過| O[PR Pass／等待人工驗收]
        L -->|爭議／到限／無法恢復| X
        G -->|範圍歧義／到限／無法恢復| X
        N -->|範圍歧義／到限／無法恢復| X
        X -->|需修訂設計，裁決後| E
        AD[Adopt：唯讀查核成果與控制權交接] -->|缺適用 design／plan 或 D11 確認| E
        AD -->|已核准且尚有實作| G
        AD -->|已實作，G1 待驗| H
        AD -->|G1 已核對適用| I
        V[版本失效：保存歷史並重評] -->|需重評 G1| H
        V -->|G1 可沿用，重查 G2／G3| I
        V -->|需重新確認 design／plan| E
    end

    D -->|Feature spec／AC 與 baseline| E
    O -->|PR Pass package| P
    P -->|既有 AC 未達成：記錄 finding 與退回版本| T
    O -->|新 push／base／spec 等版本變更| V
    P -->|新 push／base／spec 等版本變更| V
```

圖中的 Phase 0 可由既有合格基礎滿足，不要求 brownfield 重做；若需 scaffolding 等程式變更，使用者與 Project Lead 準備一般交付單位，再由 controller 依核准 plan 派工，走 Feature Loop 與適用 gates，完成後再準備相依 feature。任何 phase 都可因明確原因轉 Blocked，包含 Adopt 的控制權或必要來源不明；圖中只展開主要出口。Blocked 的返回位置取決於原因：基礎設施恢復回原操作、實作缺陷回 fix，規格變更才回 design；不重做已驗證成果。依 D28，人工驗收後自動整理 Retro 改善候選；依 D27，相依 feature 等上游人工接受且 merge 後才實作，等待時可準備 spec/design。圖未包含自動 merge、close issue、release 或 deploy。

## 4. Project loop：從基礎到可交付 features

| 階段／owner | 輸入 → 產物 | 完成條件與失敗路徑 |
| --- | --- | --- |
| Intake／Project Lead | Mission、repo → project binding、限制與現有 artifacts | Repo 與權威來源可辨識；不明路徑先自行查，需求歧義回人 |
| Research／Project Lead | Code、instructions、CI、skills、runtime → 現況與缺口 | 分清事實、推論與建議；brownfield 現有 bug 不自動變成需求 |
| Project baseline／人 + Project Lead | Research、grill → mission、domain、project spec、architecture/tech、roadmap | 已決定事項有版本與理由，近期 feature 可引用；不新增 Project-ready 簽核儀式 |
| Phase 0／Implementer | 需要的 foundation → 可重現 setup/build/test/CI | 以一般交付單位採用適用 gates；既有成果驗證後沿用 |
| Feature preparation／使用者 + Project Lead | Roadmap 能力與依賴 → feature spec/AC、high-level design、ticket | Project Lead 提出候選，使用者選定；slice 可由單一 PR 交付，太大先拆，任務拆分留在 plan |
| Acceptance／人 + Project Lead | PR Pass package → accepted 或具理由的退回 | 接受對應版本；缺陷／新需求／規格錯誤走第 7 節路徑 |
| Retro / Replanning／Project Lead | 人工接受觸發自動整理交付證據與改善候選；必要時提出 baseline/roadmap 調整 | 改善有 owner、驗法與適用版本；落地依既有權限，重大取捨交人 |
| Next feature／使用者 + Project Lead | Accepted 成果、merge 事實、依賴 → 下一個候選 | Project Lead 提出候選、使用者選定；依 D27 等上游人工接受且 merge 才實作；等待時可準備 spec/design，核對實際採用 baseline |

Mission、tech、roadmap、CONTEXT 與 spec 是文件角色，不是強制每個角色各一檔。採原 repo 或所選工具的結構：例如 P03 的 issue #12 + 引用設計、`docs/superpowers/plans/P03-ingest.md`、`docs/validation/P03-validation.md`。Controller 保存實際 references；不產生另一套同義 spec / requirements / tasks。

## 5. Feature loop：每一步的交接

| 階段 | 產物與通過條件 | 下一步／退回 |
| --- | --- | --- |
| Intake / adopt | 固定 issue、repo、owner、branch/base、適用 artifacts；既有成果與缺口有紀錄 | 依已有成果進 planning、implementing 或 validating / checking；既有 design/plan 有適用版本的 D11 確認就沿用，缺確認則先 awaiting_approval；控制權或必要來源不明→Blocked |
| Planning | Detailed design、可派工 DAG、scope、task→AC、測試／文件更新、風險與依賴 | 整份 design + plan 交使用者一次確認；保留確認版本 |
| Implementing | 按依賴逐 task TDD、commit、結果與 Red/Green 證據 | 成功執行不等於 gate 通過；缺陷正常修，範圍變更回人 |
| Integrating / G1 | 單一 owner 整合；最終相關與回歸驗證適用整合 head，歷史 Red 可追溯 | 通過才正式 G2 送審；可補資料／失敗回 implementing，無法取得歷史 Red 或 N/A 未裁決→Blocked，不以重跑綠燈補造歷史 |
| PR / checking | 記錄真實 PR base/head；G2 與 G3 並行，結果先保存再發布 | 同版本結果收齊才整理修正；卡住依 timeout / infra retry 處理 |
| Correcting | Finding / CI 問題合併為一批，保留 IDs、scope 與對應 commit | 新 head 回 G1，再取得新版本 G2/G3；爭議／重複無效修正／到限→Blocked |
| Pass | 再核對 head/base/artifact/policy 版本及三 gates；持久化判定 | PR Pass package 交 Project Lead；後續版本失效回 validating 或 checking，需新開工確認則回 planning / awaiting_approval；待發布結果繼續重試，不假稱已發布 |

依 D13，implementation 依序執行（並行度 1）；不同 tasks 可以預先研究。若日後要改為並行，需新決策修改 D13，屆時各 worker 使用隔離 worktree，依賴與檔案 scope 必須相容；最終只有整合後 PR 能取得 Pass。

## 6. Gates、finding 與版本

- **G1**：task/AC 對應歷史 Red 與後續修正；最終 Green / regression 適用當前整合版本。只有綠燈、console 完成或測試總數都不夠。D26 選用 Superpowers TDD；純文件／註解 N/A 先由獨立 Reviewer 核對適用性，再判 G1，之後才正式 G2。設定等依實際行為判定，Implementer 不可自行豁免。
- **G2**：獨立 Reviewer 對照 spec、design、完整 PR diff、必要 codebase 與適用規範。成功執行仍可判 `changes_required`；未解決 blocking findings 必須為零。
- **G3**：從 GitHub 讀必要 checks，不從 agent 摘要推定。Required 集合必須明示並核對 repo 規則；空集合、缺項、pending、cancelled、timeout、unknown 不得當成功。建議 skipped/neutral 預設不接受，例外由明確 policy 指定。

當前 gate 判定綁定 repo/PR、head、review base/merge-base、spec/design/plan/policy 版本。新 push 使當前結論過期，重新驗證；非程式文件變更由影響評估決定需重跑哪些驗證，不要求所有歷史 Red 重做。可保留的證據須留適用理由，Reviewer 對新規格與修正重新下結論。

Review finding 由 Reviewer 提出；人工驗收的 finding 依第 7 節保存。Implementer 可回 `fix_submitted` 或 `disputed`；只有 Reviewer 覆核或明確人工裁決可解除 blocking。現有 ID 隨改名、行號與輪次沿用；位置相同不一定同一問題、文字相似也不能自動合併。語意判斷交 agent，controller 檢查引用與 closure 權限。依 D24，本機 JSON registry 為 finding 狀態權威，PR 保存完整 review，原 issue 發可採取行動的摘要與連結。

### Implementer ↔ Reviewer 交手

1. Controller 送出固定版本的 review assignment，派獨立 Reviewer session。
2. Reviewer 產出 result（verdict + findings）；由 worker 或 adapter 依契約完整保存檔案。
3. Controller 驗證並匯入 result，正常情況與同版本 G3 一起判定、組成 correction batch。
4. Implementer 的 result 逐 finding 回 `fix_submitted`（commit + evidence）或 `disputed`（依據 + 可重現結果）；缺回應視為 result 不完整。需要改 scope/spec 時回 `blocked`，依 D11 交人。
5. 新 head 先重過 G1，再由 controller 派 Reviewer 覆核。依 D25，`disputed` 的反證先交獨立 Reviewer 覆核一次；仍有 blocking 爭議就 Blocked 交人。釐清沿用原 batch、不另計修正輪次；scope/spec/AC 或設計變更直接沿 D11 回人。

Implementer 與 Reviewer 不直接傳訊或互相呼叫；Orca／runtime 的交接通知只喚醒 controller，引用已保存的 result ID/path，不攜帶權威 finding、verdict 或回應內容。Runtime 原生 assistant messages 可由 adapter 捕捉為 result，與 agent 間通知分開。

「以檔案為準」是交接通道，D24 另指定本機 JSON registry 為 finding 狀態權威；controller 核對結果後匯入。GitHub 留言可作為新證據或裁決來源，不能直接關閉本機 finding；解除 blocking 仍需 D09 的 Reviewer 覆核或明確人工裁決。

詳細的版本、派工、結果、例外與恢復契約見 [workflow-contracts.md](workflow-contracts.md)。

## 7. 人工介入與退回

| 情境 | 動作與下一位 owner |
| --- | --- |
| 人工驗收發現原 AC／已核准設計未達成 | Controller 保存人工退回的版本與 stable finding（source=human_acceptance）；沿用同一 run，先查 D13 剩餘預算，再派 Implementer 修正、Reviewer 覆核；到限→Blocked |
| 原需求以外的新想法 | Project Lead 建立候選 feature；若要併入當前 scope，先明確裁決並更新 design/plan/AC 版本 |
| Spec / design 本身錯誤 | Project Lead 整理影響與方案，交使用者裁決；不降低 AC 來掩蓋程式缺陷 |
| Reviewer 與 Implementer 對 blocker 有爭議 | Controller 保存反證並交獨立 Reviewer 覆核一次；仍有 blocking 爭議則 Blocked，Project Lead 協助向使用者呈現雙方依據。沿用原 batch，不重抽 reviewer 消除 finding |
| 必要環境／權限缺失或 runtime 無法查詢 | Controller 保存 Blocked 與最小恢復條件；未確定舊 worker 結束時不派競爭 writer |
| 新風險或不可逆副作用 | 在允許執行之前提出具體影響與需人決定事項；人工 review 深度提案見原草案 |

正常 finding 修正與 CI 診斷在已批准 scope 內持續執行，不逐 task 重新請人批准。`PR Pass`、phase `ready_for_acceptance` + Human acceptance `pending`、Human acceptance `accepted`、GitHub `merged` 分開：接受不授權自動 merge；PR 新版本也不沿用舊版本的接受紀錄。人工退回缺陷沿用同一 run 與最多三輪 correction 上限，不重置預算；以被退回的交付版本為基準，首次退回不要求先有 accepted 紀錄。Finding 的 identity、來源及歷史接受紀錄見執行契約。

## 8. Retro 接回下一個 feature

依 D28，節奏為「開發中保存線索 → 人工驗收後自動整理 Retro 改善候選 → 有跨 feature 影響才 Replanning」。Orchestrate 明示整合回顧方法，不隱式呼叫 Matt user-only 原版 skill。第一輪挑 1–3 個有依據的改善，記錄來源、原因（事實或假設）、改善、承接者、驗法與落地版本；下一個相關 feature 再看重犯與誤報。

修復當前必要缺陷留在原 fix loop；可獨立的規範／工具改善作 follow-up。修改已核准 spec/AC、架構、gate policy 或工具權限沿 D11 回人。沒有改善不造待辦或 no-change 簽核。完成快照與 findings 保存後，再按需要換 fresh session；context reset 本身不是交接。

D22：P03 是第一次 Retro 試用對象，等使用者明確開始。若尚在 pre-PR，就只回顧已完成部分，後續 PR/CI/驗收列為未涵蓋；不啟動新的 PR gating loop。Matt 原版 user-only skill 的限制及選用契約見 [Retro 接入設計](orchestrate-workflow-draft.md#retro-接入設計建議)。

## 9. 最小實作形態與 skills

依 D30，workflow／controller 核心只依賴穩定的角色、派工／結果與能力契約；底層 runtime／model 透過 adapter 與設定接入。換工具仍需驗證派工、恢復、結果及隔離能力，不因可替換而放寬 gates。G2 既有獨立 Codex review 要求維持；Codex 的 runtime/model 定義仍待決，不由此選定 opencode。

初始部署沿用 D08 的 lead agent + 小型持久化 controller。相較純 prompt：可以確定地處理 SHA、重試及恢復；相較全面 workflow framework：用本機檔案、單一 process 與既有 Orca/GitHub 就能先驗證。現階段不新增 dashboard、多 repo swarm 或第二個 scheduler。

依 D17 使用單一 `orchestrate` 入口；建議以 router 按意圖載入 project / feature / adopt-resume / retro references；共用 gate、assignment/result 與 owner 契約。Skill 程序與輸出範圍見 [契約文件](workflow-contracts.md#skills-交接契約)。自動呼叫限制不靠 wrapper 名稱繞過；保留原方法或明示整合調整。

Controller 建議為本機 Python CLI，YAML 保存設定、JSON 保存狀態、JSONL 保存事件；運作原子性見 [file-state.md](file-state.md)。Orca/GitHub/git/CI 經窄 adapters 操作，核心規則可用 fake adapters 測。實際語言與執行命令將在 implementation plan 固定，目前沒有可直接啟動的產品指令。

## 10. 驗證與交付順序

| 步驟 | 要證明什麼 | 可交付成果 |
| --- | --- | --- |
| V1 設計收斂 | 決策、角色、全部正常／退回路徑與 artifacts 一致 | 本設計、契約、政策選擇；正式 OpenSpec design/specs 與 Writing Plans 可派工 plan |
| V2 核心規則 | 舊版本、缺證據、未知 check、未解 blocker 不放行；round 與 retry 分開 | 經 TDD 驗證的 gate evaluator／狀態轉移 |
| V3 持久化與恢復 | Crash、重複結果、遺失通知、未知發文結果不重派／重貼 | 檔案 store、outbox、reconcile 與故障注入證據 |
| V4 真實 adapters | 正確 workspace / worker 身份、隔離、結構化結果與生命週期 | 有界 Orca/Claude/Codex/GitHub integration 證據 |
| V5 Skills dry run | 新 session 讀交接能接續、不繞過 gates、不啟動第二 loop | 可安裝 skill、範例與操作說明，mock 明確標示 |
| V6 真實試用 | 核准目標上 finding → fix → re-review，最新版本三 gates | PR Pass package／Blocked 證據；之後再驗完整下一個 feature |

先完成 V1 的正式 plan 與一次具體開工確認，再執行程式開發。初始手工研究報告並不證明 V4 已過：先前 Codex native completion、reviewer 工具隔離與新 repo workspace discovery 都有未解缺口。實驗開始前重查現況，參見 [integration-gaps.md](research/2026-09-25/integration-gaps.md)。

目前工作順序維持：流程／skills 先準備好；P03 Retro 可由使用者單獨啟動；PR gating 試用等待恢復指示；下一個 feature 才走全流程。開工確認只對具體 design/plan 版本生效。

## 11. 本輪決策前緣

D24–D28 已確認 finding 權威／發布、一次爭議覆核、TDD／非行為例外、相依 feature 啟動條件及自動 Retro 候選；CIT 依 D29 暫不處理，G3 維持必要 CI。

D30 已確認不綁定底層實作；接下來將 G2 Codex 的 runtime/model 定義、具體 runtime 選擇與可用能力、repo-specific required checks、timeout／active time 計算及 skill 包裝落入具體 implementation plan。這些不改動已確認的角色、三 gates 與預算上限。正式開工仍依 D11 確認具體 design + plan；恢復 PR 試用前另核對 Q-TARGET 與原 owner 交接。
