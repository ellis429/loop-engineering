# 決策狀態

日期：2026-09-25。此文件記錄確認來源，不替代正式 spec。建議尚未得到回答時，不當成已授權政策。

2026-09-26 補充：使用者希望建立「Loop Engineering」並詢問整套流程如何實現。已整理 [流程藍圖](loop-engineering.md)。這是整體目標的延伸說明，當時不視為 Q-TDD / Q-PUBLISH 的答案（後續分別以 D26 / D24 確認；舊 Q-DEMO 後由 D15 取代），也不推定授權更改 repo 名稱。

## 已確認

| ID | 決策 | 來源 |
| --- | --- | --- |
| D01 | 三 gates：G1 實作/TDD、G2 獨立 review、G3 CI；結果必須驗證證據與適用版本。歷史 Red 追溯同一 task／後續修正；最終 Green／回歸適用目前整合 head，不要求 Red 與 Green 同 SHA | 初始 handoff（補記原已確認的證據語意） |
| D02 | Workflow 定義規則、controller 執行規則與持久化狀態、skills 提供方法、adapters 操作工具 | 初始 handoff |
| D03 | 終點 PR Pass / Ready for human acceptance，不自動 merge/close/release/deploy | 初始 handoff |
| D04 | Project spec 定義共用契約；feature spec 引用它並定義本次行為與驗收，可放 ticket 內文或引用文件 | 使用者「yes」確認層級 |
| D05 | 每個可獨立驗收 feature / 完整切片一個 PR，tasks 為派工單位；過大則先拆 feature | 使用者「yes」確認層級與流程 |
| D06 | 獨立 repo：`/Users/johnson.chiang/workspace/orca-delivery` | 使用者「all ok」接受三個建議 |
| D07 | 本次規格採 OpenSpec；接受 to-spec 作未來規格來源，但不因此要求自動維護兩套 authoring workflows | 同上 |
| D08 | Orca lead agent + 單一本機小型持久化 controller + Orca workers；先從專用 Orca terminal 啟動與 resume | 同上 |
| D09 | Review findings 需 reviewer 驗證或明確人工裁決才能解除；通知不能作為成功證據 | 初始 handoff |
| D10 | 真實驗收含 finding → fix → re-review，mock 與真實證據明確區分 | 初始 handoff |
| D11 | 每個 feature 的 design+plan 開工前由使用者確認一次；後續 scope/spec/AC 變更、設計缺陷或阻擋爭議回到人 | 使用者「ok'」接受上一輪三項建議 |
| D12 | 違反 spec/AC、可證明的正確性/安全缺陷、必要驗證缺失皆 blocking；風格/命名偏好不 blocking；severity 用於排優先順序 | 同上 |
| D13 | Run 主動執行時間上限 4h、最多 3 輪 correction；每個 infra 操作額外重試 2 次；實作序列、review+CI 並行；到限保存狀態轉 Blocked | 同上 |
| D14 | MVP 採人可閱讀的 JSON／YAML 檔案保存設定與狀態，取代 SQLite 提案；持久化、恢復與去重要求維持 | 使用者「我建議用 json 或是 yaml, 讓人也看得懂」 |
| D15 | 真實實驗使用另一個既有 gigaxfer session 正在開發的 feature；不採建立新 private orca-delivery repo／status feature 的 demo 提案 | 使用者「我想用另一個 session gigaxfer 來實驗」及後續說明 |
| D16 | 先驗證 PR gating loop，從該 feature 到 pre-PR 時接入 G1 → PR → 獨立 review/CI → fix/re-review → PR Pass／Blocked；既有 session 繼續初始實作 | 使用者「等等他做到 pre-pr 的時候試試看」、「我們可以先驗證 pr gating loop」 |
| D17 | 共同入口 `orchestrate` 分 project / feature 兩層：project 由使用者與 Project Lead Agent 建立基礎、選 feature 與 final acceptance；feature 由 Implementer Agent 協調交付、Reviewer Agent 獨立 review | 使用者 2026-09-26 Project loop / Feature Loop 描述 |
| D18 | 現有 PR 試用暫緩；先把流程與 skill 做好，再讓現有 PR 試用；下一個 feature 從頭採新流程 | 使用者「先讓 PR 停在那…下一個 feature 就要套用新流程」 |
| D19 | 優先落實三項：AC 以穩定 ID 描述情境/操作/可觀察結果；AC 對應驗證方法及實際證據，併入既有一次 design+plan 確認；交接實際文件位置與適用版本，保留工具原生檔名。修 code 不得自行降低 AC，語意變更沿 D11 回使用者與 Project Lead Agent 裁決 | 使用者在三項優先建議後回覆「恩 可以寫在我們 loop 的設計」 |
| D20 | 統一角色名稱：Project Lead Agent（原 Tech Lead / TL）、Implementer Agent（原 Engineer 1）、Reviewer Agent（原 Engineer 2）。職責沿用 D17；命名調整不改變人工裁決、單一 controller 或 G2 獨立審查邊界 | 使用者「我們把 Engineer 1 和 2 改成 Implementer Agent 和 Reviewer Agent?」、「Tech Lead 就變成 Project Lead Agent ?」 |
| D21 | 在 loop 設計中加入 Retro，涵蓋執行品質的回顧與 project Replanning；具體時點、頻率、skill 呼叫與改善落地方式由設計提出，不將影片整理全部視為已授權政策 | 使用者提供雙層 Retro 整理並詢問「我想把 retro 加入 在哪個時間點好 怎麼做」 |
| D22 | 首次 Retro 試用對象選 P03，等使用者稍後指定開始。屆時依實際進度界定回顧範圍；這次選定不等於啟動 Retro、恢復 PR gating 試用或接管原 Looper | 使用者「好 我等等也可以用 P03 來試著做」 |
| D23 | Project Lead、Implementer、Reviewer 為同層協作角色；Project／Feature 是工作範圍層級，不建立固定的 agent 上下指揮鏈。使用者可透過共同入口直接與任一角色協作；Project Lead 與 Implementer 以 spec／AC、依賴及成果交接。只有使用者明確授權時，Project Lead 才在指定範圍代理安排日常工作。Controller 依核准 plan 維持唯一派工與狀態／gate 核查；D11 的人工裁決及 G2 獨立性維持 | 使用者重新討論是否需要階層後，對「三角色同層協作、明確授權才代理安排」回覆「同意」（2026-09-26）；取代變更請求 1A 的固定指揮鏈提案 |
| D24 | Finding 狀態以本機 JSON registry 為權威；PR 發完整 review，原 issue 發可採取行動的摘要與連結。先持久化結果，再經 outbox 發布及 reconcile；GitHub 討論須匯入為證據／裁決，不直接形成第二套狀態。解除 blocking 沿 D09 | 使用者對第 1 項建議回覆「1-5 ok」（2026-09-26） |
| D25 | Implementer 對 finding 提出反證後，由 controller 交獨立 Reviewer 覆核一次；仍有 blocking 爭議即 Blocked 交使用者。這次釐清沿用原 correction batch，不另計修正輪次；不得以換 session／重複通知重置次數。Scope/spec/AC 或設計變更仍直接沿 D11 回人 | 同上，第 2 項：爭議先覆核一次，再回人 |
| D26 | TDD 方法採 Superpowers TDD；純文件／註解可提出附理由與檢查的 N/A，由獨立 Reviewer 確認。先完成 N/A eligibility 檢查再判 G1，之後才正式 G2；eligibility 不等於 review clean。設定／migration／test code 依實際行為判定，Implementer 不可自行豁免；證據版本沿 D01 | 同上，第 3 項：TDD 方法與非行為例外 |
| D27 | 有依賴的下一個 feature，等上游人工接受且 merge 後才開始實作；等待時可準備 spec/design。核對實際 merge 與採用 baseline，不把 accepted 或 PR Pass 視為 merged；不授權自動 merge | 同上，第 4 項：相依 feature 啟動條件 |
| D28 | Feature 人工驗收後，由 orchestrate 自動整理 Retro 改善候選，Project Lead 彙整證據；改善落地仍依既有 scope／決策權限，不自動改 code、spec 或 gate policy。明示整合 Matt 方法與輸出契約，不隱式呼叫 user-only 原版 skill；P03 的提前試用仍依 D22 等明確開始 | 同上，第 5 項：Retro 觸發 |
| D29 | CIT 暫不處理；G3 維持已確認的必要 CI 定義，不新增 gate，也不以 CIT 定義未決阻擋目前設計 | 使用者「6 先不管他」（2026-09-26） |
| D30 | Workflow／controller 核心與底層 runtime／model 的具體實作解耦：角色、gates、assignment/result 契約維持穩定，由 adapter 與設定提供執行能力及選型。這是架構原則，不等於選定 model-only G2、採用 opencode 或撤銷既有獨立 Codex review 要求；Codex 的 runtime/model 定義及具體 adapter 仍待定 | 使用者撤回誤輸入「改用 model」後，補充「不過不綁定底層確實是好的」（2026-09-26） |

## 已提出，待回答

| ID | 建議 | 主要取捨 |
| --- | --- | --- |
| Q-TARGET | PR gating 試用：已選 gigaxfer 的既有 session；確認是否為 P03 / issue #12 / p03-ingest，再固定 pre-PR 交接版本和 session identity | P03 仍在修改且依賴 open PR #11；目前只是查核到的候選，不能自行當成使用者選定 |

已收斂：Q-PUBLISH → D24、finding 爭議覆核 → D25、Q-TDD → D26、Q-NEXT → D27、Q-RETRO → D28；CIT 依 D29 暫緩。

## 下一個決策前緣

完整流程已整合為 [Workflow Design v1](workflow-design.md) 與 [執行契約](workflow-contracts.md)。D24–D28 已收斂本輪五項政策。D30 確認核心與底層實作解耦；G2 Codex 的 runtime/model 定義仍待選定。後續將 runtime 選擇、必要 CI checks、timeout 與 active time 計算落入具體 design / implementation plan，再依 D11 作一次開工確認；CIT 依 D29 暫不處理。

依 D18，先完善 [Workflow Design v1](workflow-design.md)／[執行契約](workflow-contracts.md) 與 skill，現有 PR 試用維持暫緩。使用者貼上的外部 SDD 方法已在草案末節對照；D19 已確認輕量 AC/驗證對照與文件版本交接；D21 已確認加入 Retro 的方向；D28 已確認驗收後自動產出改善候選，完整 scorecard schema 與具體 skill 包裝仍是實作提案，不把參考文章整體視為已核准政策。

使用者後續釐清課程定位為輕量人機協作，未直接涵蓋先前七項治理細節；這是來源範圍補充，不視為新增治理要求。助理已在 [MVP 取捨](workflow-gap-review.md) 縮小候選方案，原先已確認的 gates、版本與恢復要求維持。

Q-TARGET 在恢復現有 PR 試用前重新核對，不依過期 P03 狀態自動接管。既有 feature 的歷史 TDD 證據若缺失，如實回報；下一個 feature 從開始即保存證據。

D28 的 Retro 接點為 feature 人工驗收後，自動整理改善候選供下一個 feature 使用；共用設計或 roadmap 有影響才 Replanning。方法與包裝見 [Retro 接入設計](orchestrate-workflow-draft.md#retro-接入設計建議)。自動化由 orchestrate 明示整合方法，Matt 原版 retro 的 user-only 限制保留；改善是否落地依既有權限與必要人工決策。

使用者補充《Fixing the PR Bottleneck》摘要後，已收錄 [來源與品質層次對照](references/fixing-the-pr-bottleneck.md)，並提出 [依風險調整人工審查、精簡 PR Pass package](orchestrate-workflow-draft.md#品質層次與人工審查補充提案)。這是來源與設計候選，不新增已確認政策；三 gates、獨立 reviewer 與人工接受的邊界維持。

## 可由設計自行處理的實作細節

持久化採 D14 的人可讀檔案。格式分工建議：YAML 保存 workflow/gate 設定，排版過的 JSON 保存 run/assignment/result，JSONL 保存事件歷史；具體寫入與恢復設計見 [檔案狀態設計](file-state.md)。語言、檔案安排與內部介面仍由設計提出，需滿足已確認的行為、恢復及證據契約。

Design 草案會明列 worker/review/CI 45/30/30min 的 timeout 預設、只接受 required check 的 success（skipped/neutral 預設拒絕）、active time 計算及 budget resume 行為，隨具體 design 一併確認。現階段成本只記錄可得用量，不宣稱精確美元硬上限。
