# Orca Delivery

從 project 基礎與 feature 準備，經 feature 交付到 PR Pass，再到人工驗收與 Retro / Replanning 的交付協作領域。

## Language

**Project Lead Agent**:
與 Implementer、Reviewer 同層協作，負責和使用者維護專案方向、共用需求、架構、roadmap 及跨 feature 交接的 agent 角色。協助重要裁決與最終驗收；代理安排日常工作的範圍由使用者明確授權。
_Avoid_: Tech Lead、TL（指本角色時）

**Implementer Agent**:
與 Project Lead、Reviewer 同層協作，負責單一 feature 詳細設計、計畫、TDD 實作、整合及修正的 agent 角色；統籌 implementation 工作，交付可核查的程式與證據。
_Avoid_: Engineer 1

**Reviewer Agent**:
與 Project Lead、Implementer 同層協作，依適用規格與工程規範審查整合變更並覆核 findings 的獨立 agent 角色；不直接修改被審查分支。
_Avoid_: Engineer 2

**Model**:
Agent 執行推理所使用的模型；與負責工具、session 及執行生命週期的 runtime 分開。

**Agent runtime**:
承載 agent session、模型呼叫、工具權限與執行生命週期的執行環境。Runtime 名稱不代表實際使用的 model，也不自動保證 Reviewer 獨立性。

**Controller**:
依核准 plan 與 workflow 規則執行派工、版本及 gates 核查、持久化與結果發布的協調機制。它不是 agents 的主管，需求及品質的語意判斷由相應 agent 或使用者負責。

**Project spec**:
整體目標、共用契約、系統限制與跨功能保證的權威需求集合。

**Feature spec**:
引用 project spec，定義單次交付的可觀察行為、範圍、驗收條件與依賴的需求集合；可位於 feature ticket 內文或其引用文件。

**Feature ticket**:
追蹤一個可獨立驗收功能切片的 issue，包含或引用其 feature spec。
_Avoid_: Task ticket（用於指稱 feature 時）

**Implementation task**:
Feature plan 中具有 scope、依賴與驗證條件的派工單位，多個 tasks 可共同交付一個 feature PR。

**Delivery run**:
針對一個已選定 feature ticket，從規劃、實作到 PR Pass 或需要人工裁決的持續交付紀錄。

**Attempt**:
同一 implementation、review 或診斷 task 的一次執行；重試產生新的 attempt，保留先前紀錄。

**Orca Dispatch**:
Orca 指派給 worker 的一次具有效執行權的 task attempt，與 delivery attempt 以識別碼對應。

**Gate evidence**:
可讀取、可追溯且適用於指定交付版本的驗證紀錄，是 gate 判定依據。

**Blocking finding**:
尚未經 reviewer 覆核解除或人工明確裁決、會阻止 review clean 的問題。

**Correction round**:
同一適用版本的 review / CI 結果整理成修正批次後，經修正、驗證與重新審查的一輪。

**Execution Retro**:
從 feature 執行、審查與驗收的證據中辨識重複失誤及流程摩擦，形成可驗證改善項目的回顧活動；與修復當前 finding 的 correction round 分開。

**Replanning**:
根據交付與驗收的新知，重新決定共用需求、架構或 roadmap 的專案活動；由 Project Lead Agent 協助使用者作跨 feature 取捨。

**PR Pass**:
目前交付版本同時滿足實作/TDD、獨立 review 與必要 CI 三個 gates 的品質結論。
_Avoid_: Agent done、CI green（用於指稱全部通過時）

**Blocked**:
交付需要人工決策或外部條件變更才能正確續行的狀態，包含具體原因、證據與待決事項。
