# Orca Delivery

以 Orca 為入口，協調 Claude Code 實作與獨立 Codex review，將選定的 feature issue 推進到具備證據的 PR Pass。

目前階段：整合 workflow 設計與決策收斂。已建立獨立 repo 與 OpenSpec，尚未實作控制器，尚無真實端到端交付證據。

## 文件

- [整體 Workflow Design v1：流程、角色、驗收與 Retro](docs/workflow-design.md)
- [Workflow 執行契約：版本、結果、gates、恢復與 skills](docs/workflow-contracts.md)
- [Orchestrate：project / feature 流程草案與文件比較](docs/orchestrate-workflow-draft.md)
- [外部參考：Spec-Driven Development 工作流程](docs/references/spec-driven-development-workflow.md)
- [Retro 接入設計：feature 收尾與 project Replanning](docs/orchestrate-workflow-draft.md#retro-接入設計建議)
- [外部參考與本機查核：雙層 Retro](docs/references/dual-loop-retro.md)
- [外部參考：Fixing the PR Bottleneck 與品質層次對照](docs/references/fixing-the-pr-bottleneck.md)
- [Project / Feature 流程對照與 MVP 取捨](docs/workflow-gap-review.md)
- [第一段實驗：gigaxfer pre-PR gating loop](docs/experiments/pr-gating.md)
- [Loop Engineering：完整流程與實現藍圖](docs/loop-engineering.md)
- [JSON／YAML 檔案狀態與恢復設計](docs/file-state.md)
- [需求意圖與已確認邊界](docs/project-intent.md)
- [決策狀態](docs/decisions.md)
- [領域詞彙](CONTEXT.md)
- [環境查核與 baseline evidence](docs/research/2026-09-25/research.md)
- [Orca 控制介面](docs/research/2026-09-25/orca-capabilities.md)
- [Agent 傳訊與 opencode：版本查核、限制與未實證項目](docs/research/2026-09-26/agent-messaging-and-opencode.md)
- [真實 agent 派工 probe 與能力缺口](docs/research/2026-09-25/runtime-probe.md)
- [Codex sandbox / Orca IPC 與 workspace 整合查核](docs/research/2026-09-25/integration-gaps.md)
- [Skills 契約與版本查核](docs/research/2026-09-25/skills.md)
- [Feature 交接欄位草案](docs/research/2026-09-25/feature-handoff-contract.md)

## 工作層級

Project spec 定義共用契約；feature ticket 的內文或引用文件承擔 feature spec。每個可獨立驗收的 feature 對應一個 PR，implementation tasks 是該 PR 的派工單位。Review 同時對照適用的 project / feature specs。

角色統一為 **Project Lead Agent**（專案方向與跨 feature 協作）、**Implementer Agent**（feature 設計、實作與修正）、**Reviewer Agent**（獨立審查與覆核）。依 D23，三者同層協作，使用者可直接與任一角色合作；Project／Feature 表示工作範圍。重大裁決與最終接受由使用者決定；controller 負責唯一派工、狀態與 gate 證據核查。詳見 [角色與控制權](docs/workflow-design.md#2-角色與控制權)。

PR Pass 必須同時滿足：G1 實作與 TDD 證據、G2 獨立 review 無未解決阻擋項、G3 必要 CI 檢查成功。結論綁定目前 PR head、review base 與適用規格版本。

MVP 的執行方式已確認為 Orca workers + 單一本機持久化控制器，從專用 Orca terminal 啟動。停止於 Ready for human acceptance；merge、close issue、release、deploy 不在預設範圍。
